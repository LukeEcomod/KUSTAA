***********************************************************

KUSTAA -ty�kalu valuma-alueen vesist�kuormituksen laskentaan

v.2.06 (20.11.2014)

Menetelm�n kuvaus Launiainen ym. 2014. Suomen ymp�rist�keskuksen Raportteja 33/2014, http://hdl.handle.net/10138/144108

Uusin versio KUSTAA-ty�kalusta on ladattavissa www.metla.fi/metinfo/kustaa

Asennus: pura kaikki tiedostot samaan hakemistoon ja avaa KUSTAA 2.06.xls
K�ytt�: Katso k�ytt�ohje; KUSTAA vaatii Excel'in makrojen sallimista (kts. k�ytt�ohje). 

KUSTAA_Lahtotiedot_Esimerkkilaskelma sis�lt�� raportissa (Launiainen ym. 2014) esitetyn esimerkkilaskelman l�ht�tiedot.

Palaute: samuli.launiainen metla fi / ari.lauren metla fi
***********************************************************